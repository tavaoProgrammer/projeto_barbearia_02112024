# projeto_barbearia_0211
adição da footer com as informações de contato, bem como o botão flutuante do whatsapp